# cpp-skeleton-2019
C++ skeleton bot for Pokerbots 2019

# Building

To compile, simply type `scons` in the root directory.
