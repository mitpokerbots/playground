#include <iostream>
#include "player.hpp"

Player::Player() {
}

void Player::handle_new_game(const Game& new_game) {
  // Your code here.
}

void Player::handle_new_round(const Game& game, const Round& new_round) {
  // Your code here.
}

void Player::handle_round_over(
    const Game& game,
    const Round& round,
    const Pot& pot,
    const std::vector<std::string>& cards,
    const std::vector<std::string>& opponent_cards,
    const std::vector<std::string>& board_cards,
    const std::string& result,
    const int new_bankroll,
    const int new_opponent_bankroll,
    const std::vector<std::string>& move_history
) {
  // Your code here.
}

// Where the magic happens - your code should implement this function.
// Called any time the server needs an action from your bot.

// Arguments:
// game: the Game object.
// round: the Round object.
// pot: the Pot object.
// cards: an array of your cards, in common format.
// board_cards: an array of cards on the board. This list has length 0, 3, 4, or 5.
// legal_moves: a set of the move classes that are legal to make.
// cost_func: a function that takes a move, and returns additional cost of that move. Your returned move will raise your pot.contribution by this amount.
// move_history: a list of moves that have occurred during this round so far, earliest moves first.
// time_left: a float of the number of seconds your bot has remaining in this match (not round).
// min_amount: if BetAction or RaiseAction is valid, the smallest amount you can bet or raise to (i.e. the smallest you can increase your pip).
// max_amount: if BetAction or RaiseAction is valid, the largest amount you can bet or raise to (i.e. the largest you can increase your pip).
Action Player::get_action(
    const Game& game,
    const Round& round,
    const Pot& pot,
    const std::vector<std::string>& cards,
    const std::vector<std::string>& board_cards,
    const ActionType legal_move_mask,
    const std::vector<std::string>& move_history,
    const float time_left,
    const int min_amount,
    const int max_amount
) {
  // Your code here.

  int call_cost = action_cost(pot, CallAction());

  if (legal_move_mask & CALL_ACTION_TYPE) {
    return CallAction();
  } else {
    return CheckAction();
  }
}
